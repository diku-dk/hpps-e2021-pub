#ifndef UTIL_H
#define UTIL_H

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdint.h>
#include <math.h>

// Compute the Euclidean distance between two d-dimensional points 'x'
// and 'y'.  Usual formula:
//
//
//  √( ∑ (x[i]-y[i])² )
//
double distance(int d, const double *x, const double *y) {
  double sum = 0;
  for (int i = 0; i < d; i++) {
    sum += (x[i] - y[i]) * (x[i] - y[i]);
  }
  return sqrt(sum);
}

// Print the components of a single d-dimensional point to the given
// file, followed by a newline.
void print_point(FILE *f, int d, double *p) {
  for (int j = 0; j < d; j++) {
    fprintf(f, "%f ", p[j]);
  }
  printf("\n");
}

// Print all the n d-dimensional points to the given file, one per
// line.
void print_points(FILE *f, int n, int d, double *ps) {
  for (int i = 0; i < n; i++) {
    print_point(f, d, &ps[i*d]);
  }
}

// Read points from the given open file.  Returns the address of an
// n-by-d array in row-major order format.  Stores 'n' and 'd' at the
// provided locations.
double* read_points(FILE *f, int* n_out, int *d_out) {
  int read;
  int32_t n, d;

  read = fscanf(f, "%d", &n);
  if (read != 1) {
    return NULL;
  }

  read = fscanf(f, "%d", &d);
  if (read != 1) {
    return NULL;
  }

  double* data = malloc(n*d*sizeof(double));

  for (int i = 0; i < n*d; i++) {
    read = fscanf(f, "%lf", &data[i]);
    if (read != 1) {
      free(data);
      return NULL;
    }
  }

  *n_out = n;
  *d_out = d;
  return data;
}

#endif
