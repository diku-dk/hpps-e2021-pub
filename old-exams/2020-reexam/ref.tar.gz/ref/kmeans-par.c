#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "util.h"

int assign_cluster(int k, int d,
                   const double *centroids,
                   const double *point,
                   int *assignment) {
  int nearest = 0;
  double nearest_dist = INFINITY;

  for (int i = 0; i < k; i++) {
    double dist = distance(d, &centroids[i*d], point);
    if (dist < nearest_dist) {
      nearest = i;
      nearest_dist = dist;
    }
  }
  if (*assignment != nearest) {
    *assignment = nearest;
    return 1;
  } else {
    return 0;
  }
}

int assign_clusters(int k, int n, int d,
                    const double *centroids,
                    const double *points,
                    int *assignments) {
  int changes = 0;
  // Assign each point to the cluster with the nearest centroid.
#pragma omp parallel for reduction(+:changes)
  for (int i = 0; i < n; i++) {
    changes += assign_cluster(k, d, centroids, &points[i*d], &assignments[i]);
  }
  return changes;
}

void compute_centroids(int k, int n, int d,
                       double *centroids,
                       const double *points,
                       const int *assignments) {
  // Compute size of each cluster.
  int *cluster_sizes = calloc(k, sizeof(int));
  for (int i = 0; i < n; i++) {
    cluster_sizes[assignments[i]]++;
  }

  // Compute new centroid of each cluster.
  for (int i = 0; i < k*d; i++) {
    centroids[i] = 0;
  }

  for (int i = 0; i < n; i++) {
    const double* point = &points[i*d];
    double* centroid = &centroids[assignments[i]*d];
    int size = cluster_sizes[assignments[i]];
    for (int j = 0; j < d; j++) {
      centroid[j] += point[j]/size;
    }
  }

  free(cluster_sizes);
}

int main(int argc, char** argv) {
  if (argc != 3) {
    fprintf(stderr, "Usage: %s <k> <inputfile>\n", argv[0]);
    exit(1);
  }

  int k = atoi(argv[1]);
  int n;
  int d;

  const char *fname = argv[2];
  FILE *points_f = fopen(fname, "r");
  assert(points_f != NULL);
  double *points = read_points(points_f, &n, &d);
  fclose(points_f);
  assert(n >= k);

  int *assignments = calloc(n, sizeof(int));
  double *centroids = calloc(k*d, sizeof(double));

  // Initialise the centroids to the first 'k' points.
  memcpy(centroids, points, k*d*sizeof(double));

  int limit = 500;
  int round = 0;
  for (round = 0; round < limit; round++) {
    // Assign points to the nearest cluster.
    int changes = assign_clusters(k, n, d, centroids, points, assignments);
    printf("Round %3d: %9d changes\n", round, changes);
    if (changes == 0) {
      break;
    }
    compute_centroids(k, n, d, centroids, points, assignments);
  }
  printf("Centroids:\n");
  print_points(stdout, k, d, centroids);

  free(points);
  free(assignments);
  free(centroids);
}
