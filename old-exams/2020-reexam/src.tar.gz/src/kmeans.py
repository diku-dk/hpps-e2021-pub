#!/usr/bin/env python3

import numpy as np
import sys

def load_points(infile):
    return np.loadtxt(infile, dtype=np.double, skiprows=1)

def print_points(points):
    n,d = points.shape
    for i in range(n):
        for j in range(d):
            print('%f ' % points[i,j], end='')
        print('')

def assign_clusters(centroids, points):
    k,_ = centroids.shape
    n,d = points.shape

    def assign_cluster(point):
        nearest = 0
        nearest_dist = np.inf
        for i in range(k):
            dist = np.linalg.norm(centroids[i]-point)
            if dist < nearest_dist:
                nearest = i
                nearest_dist = dist
        return nearest

    assignments = np.zeros(n, dtype=np.int)
    for i in range(n):
        assignments[i] = assign_cluster(points[i])
    return assignments

def compute_centroids(k, points, assignments):
    n,d = points.shape

    # Compute size of each cluster.
    cluster_sizes = np.zeros(k, dtype=np.double)
    for i in range(n):
        cluster_sizes[assignments[i]] += 1

    # Compute new centroid of each cluster.
    centroids = np.zeros((k,d), dtype=np.double)
    for i in range(n):
        centroids[assignments[i]] += points[i]/cluster_sizes[assignments[i]]

    return centroids

def kmeans(k, pointsfile):
    points = load_points(pointsfile)
    n,d = points.shape

    # Initialise centroids to first k points.
    centroids = points[0:k]

    # Assign all points to first cluster (we'll recompute this immediately).
    assignments = np.zeros(n, dtype=np.int)

    limit = 500
    round = 0
    while round < limit:
        new_assignments = assign_clusters(centroids, points)
        print('Round %3d.' % round)
        # Break if there have been no changes to assignments.
        if (np.count_nonzero(assignments != new_assignments) == 0):
            break
        assignments = new_assignments
        round += 1
        centroids = compute_centroids(k, points, assignments)
    print('Centroids:')
    print_points(centroids)

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 kmeans.py <k> <inputfile>")
        exit(1)
    kmeans(int(sys.argv[1]), sys.argv[2])
