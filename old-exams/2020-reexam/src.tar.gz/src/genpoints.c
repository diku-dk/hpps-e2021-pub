#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "util.h"

int main(int argc, char** argv) {
  if (argc != 3) {
    fprintf(stderr, "Usage: %s N D\n", argv[0]);
    exit(1);
  }

  int n = atoi(argv[1]);
  int d = atoi(argv[2]);

  srand(n ^ d);

  printf("%d %d\n", n, d);

  double *p = calloc(d, sizeof(double));

  for (int i = 0; i < n; i++) {
    for (int j = 0; j < d; j++) {
      p[j] = (double)rand() / RAND_MAX * 100;
    }
    print_point(stdout, d, p);
  }
}
