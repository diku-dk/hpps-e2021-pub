#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "util.h"

int main(int argc, char** argv) {
  if (argc != 3) {
    fprintf(stderr, "Usage: %s <k> <inputfile>\n", argv[0]);
    exit(1);
  }

  int k = atoi(argv[1]);
  int n;
  int d;

  const char *fname = argv[2];
  FILE *points_f = fopen(fname, "r");
  assert(points_f != NULL);
  double *points = read_points(points_f, &n, &d);
  fclose(points_f);
  assert(n >= k);

  // TODO

  // Uncomment when you have a 'centroids' variable.
  // printf("Centroids:\n");
  // print_points(stdout, k, d, centroids);
}
