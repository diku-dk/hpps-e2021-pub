#!/usr/bin/env bash

set -e

# Toggle here to change executable
#COMMAND="python3 nbody.py"
COMMAND="./nbody-par"

# Number of steps computed for each frame
STEPS_PR_FRAME=100

if [ "$1" = "" ]; then
    echo "Usage:"
    echo "bash create-animation.sh <??-bodies.txt>"
    exit 1
fi

if [ ! -f "$1" ]; then
  echo "Input dataset not found: $1"
  exit 1
fi

if [ ! -d "datafiles" ]; then
    mkdir datafiles
fi

prev=$1
names=$1

echo "Drawing 100 frames with $STEPS_PR_FRAME steps each ..."

for n in {1..100}; do
    echo "Rendering frame $n..."
    next="datafiles/frame_${n}.txt"
    echo "${COMMAND} ${prev} ${next} ${STEPS_PR_FRAME}"
    ${COMMAND} "${prev}" "${next}" "${STEPS_PR_FRAME}"
    names="${names} ${next}"
    prev="${next}"
done

echo "Creating animated.gif output with command:"
echo "python3 animate.py $names"
python3 animate.py $names


