#include "util.h"

static const double epsilon = 50;

void nbody(int n, struct particle *ps, int steps) {
  double *xs = malloc(n*sizeof(double));
  double *ys = malloc(n*sizeof(double));
  double *zs = malloc(n*sizeof(double));
  double *ms = malloc(n*sizeof(double));
  double *vxs = malloc(n*sizeof(double));
  double *vys = malloc(n*sizeof(double));
  double *vzs = malloc(n*sizeof(double));

// Transpose structs for sequential access
#pragma omp parallel for
  for (int i = 0; i < n; i++) {
    xs[i] = ps[i].x;
    ys[i] = ps[i].y;
    zs[i] = ps[i].z;
    ms[i] = ps[i].mass;
    vxs[i] = ps[i].vx;
    vys[i] = ps[i].vy;
    vzs[i] = ps[i].vz;
  }

  for(int s = 0; s < steps; s++) {
#pragma omp parallel for
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < n; j++) {
        double rx = xs[j] - xs[i];
        double ry = ys[j] - ys[i];
        double rz = zs[j] - zs[i];
        double s = ms[j] * pow(1 / sqrt(rx*rx + ry*ry + rz*rz + epsilon*epsilon), 3);
        double ax = rx * s;
        double ay = ry * s;
        double az = rz * s;
        vxs[i] += ax;
        vys[i] += ay;
        vzs[i] += az;
      }
    }

#pragma omp parallel for
    for (int i = 0; i < n; i++) {
      xs[i] += vxs[i];
      ys[i] += vys[i];
      zs[i] += vzs[i];
    }
  }

// Write back to structs
#pragma omp parallel for
    for (int i = 0; i < n; i++) {
      ps[i].vx = vxs[i];
      ps[i].vy = vys[i];
      ps[i].vz = vzs[i];
      ps[i].x = xs[i];
      ps[i].y = ys[i];
      ps[i].z = zs[i];
    }

  free(xs);
  free(ys);
  free(zs);
  free(ms);
  free(vxs);
  free(vys);
  free(vzs);
}

int main(int argc, char** argv) {
  int steps = 1;
  if (argc < 3) {
    printf("Usage: \n");
    printf("%s <input> <output> [steps]\n", argv[0]);
    return 1;
  } else if (argc > 3) {
    steps = atoi(argv[3]);
  }

  int n;
  struct particle *ps = read_particles(argv[1], &n);

  double bef = seconds();
  nbody(n, ps, steps);
  double aft = seconds();
  printf("%fs\n", aft-bef);
  write_particles(argv[2], n, ps);
}
