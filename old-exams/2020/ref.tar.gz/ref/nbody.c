#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include "util.h"

static const double epsilon = 50;

void nbody(int n, struct particle *ps, int steps) {
  for(int s = 0; s < steps; s++) {
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < n; j++) {
        double rx = ps[j].x - ps[i].x;
        double ry = ps[j].y - ps[i].y;
        double rz = ps[j].z - ps[i].z;
        double m = ps[j].mass;
        double s = m / pow(rx*rx + ry*ry + rz*rz + epsilon*epsilon, 1.5);
        double ax = rx * s;
        double ay = ry * s;
        double az = rz * s;
        ps[i].vx += ax;
        ps[i].vy += ay;
        ps[i].vz += az;
      }
    }

    for (int i = 0; i < n; i++) {
      ps[i].x += ps[i].vx;
      ps[i].y += ps[i].vy;
      ps[i].z += ps[i].vz;
    }
  }
}

int main(int argc, char** argv) {
  int steps = 1;
  if (argc < 3) {
    printf("Usage: \n");
    printf("%s <input> <output> [steps]\n", argv[0]);
    return 1;
  } else if (argc > 3) {
    steps = atoi(argv[3]);
  }

  int n;
  struct particle *ps = read_particles(argv[1], &n);

  double bef = seconds();
  nbody(n, ps, steps);
  double aft = seconds();
  printf("%fs\n", aft-bef);
  write_particles(argv[2], n, ps);
}
