#!/usr/bin/env python3

import numpy as np
import sys

_, n, outfile = sys.argv
arr = np.random.rand(int(n), 7).astype(np.double)
arr[:,1:4] *= 1000
arr[:,4:7] = 0
np.savetxt(outfile, arr)
