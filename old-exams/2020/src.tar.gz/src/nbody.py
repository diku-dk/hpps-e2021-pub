#!/usr/bin/env python3

import numpy as np
import sys

def load_points(infile):
    arr = np.loadtxt(infile)
    n = arr.shape[0]
    # Convert rows to dicts representing points.
    points = [None] * n
    for i in range(n):
        points[i] = { 'mass': arr[i,0],
                      'x': arr[i,1],
                      'y': arr[i,2],
                      'z': arr[i,3],
                      'vx': arr[i,4],
                      'vy': arr[i,5],
                      'vz': arr[i,6]}
    return points

def save_points(outfile, points):
    with open(outfile, 'w') as f:
        for p in points:
            f.write("%f %f %f %f %f %f %f\n" %
                    (p['mass'], p['x'], p['y'], p['z'], p['vx'], p['vy'], p['vz']))

epsilon = 50

def nbody(points, steps):
    for _ in range(steps):
        for a in points:
            for b in points:
                rx = b['x'] - a['x']
                ry = b['y'] - a['y']
                rz = b['z'] - a['z']
                m = b['mass']
                s = m / ((rx*rx + ry*ry + rz*rz + epsilon*epsilon) ** 1.5)
                ax = rx * s
                ay = ry * s
                az = rz * s
                a['vx'] += ax
                a['vy'] += ay
                a['vz'] += az

        for a in points:
            a['x'] += a['vx']
            a['y'] += a['vy']
            a['z'] += a['vz']


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python3 nbody.py <inputfile> <outputfile> [steps]")
        exit(1)

    infile = sys.argv[1]
    outfile = sys.argv[2]
    steps = 1
    if len(sys.argv) > 3:
        steps = int(sys.argv[3])

    points = load_points(infile)
    nbody(points, steps)
    save_points(outfile, points)
