#!/usr/bin/env python3

import numpy as np
import os
import sys

# May require
# pip3 install array2gif
from array2gif import write_gif

def load_points(infile):
    arr = np.loadtxt(infile)

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python3 animate <dataset-1> <dataset-2> ... <dataset-N>")
        exit(1)

    # Check if files exist
    for n in sys.argv[1:]:
        if not os.path.isfile(n):
            print(f'The dataset file %s could not be found' % n)
            exit(1)

    # Load datasets
    datasets = np.array([np.loadtxt(n) for n in sys.argv[1:]])

    # Assuming most particles are in the 0-1000 range, this will
    # normalise them to 0-1
    datasets /= 1000

    # Prepare output buffer
    n = 100
    m = 100
    pixels = np.empty([datasets.shape[0], n, m, 3])
    pixels[:] = 255 #Make white background

    for i in range(datasets.shape[0]):
        for body in datasets[i]:
            x = int(body[1] * (pixels.shape[1] - 1))
            y = int(body[2] * (pixels.shape[2] - 1))
            # Only show particles that are in bounds
            if 0 <= x and x < n and 0 <= y and y < m:
                pixels[i][x][y][:] = [255, 0, 0] # Make a red pixel

    write_gif(pixels, 'animated.gif', fps=15)
